import FriendsSection from './friends/FriendsSection';
const LeftSide = () => {
    return (
        <section>
            <FriendsSection />
        </section>
    )
}
export default LeftSide;