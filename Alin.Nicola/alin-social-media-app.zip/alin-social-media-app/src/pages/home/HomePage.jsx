import StartingPage from "../startingPage/StartingPage";

const HomePage = () => {
    return (
        <>
            <StartingPage/>
        </>
    )
}

export default HomePage;