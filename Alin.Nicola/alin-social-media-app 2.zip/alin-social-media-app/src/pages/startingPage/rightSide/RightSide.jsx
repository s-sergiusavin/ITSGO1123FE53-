import InterestsSection from './interests/InterestsSection';
const RightSide = () => {
    return (
        <section>
            <InterestsSection />
        </section>

    )
}

export default RightSide;